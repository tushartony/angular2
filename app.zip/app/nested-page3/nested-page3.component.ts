import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nested-page3',
  templateUrl: './nested-page3.component.html',
  styleUrls: ['./nested-page3.component.css']
})
export class NestedPage3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
