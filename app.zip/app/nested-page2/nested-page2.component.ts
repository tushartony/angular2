import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nested-page2',
  templateUrl: './nested-page2.component.html',
  styleUrls: ['./nested-page2.component.css']
})
export class NestedPage2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
